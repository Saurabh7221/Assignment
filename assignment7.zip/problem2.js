//Print Prime Numbers from 1 to given limit


for (let i=1;i<=50;i++){
  let count=0;
  for(let j=1;j<=50;j++){
  
    if (i%j==0){
      count+=1
    }
  }
  
  if (count==2){
    console.log(i,"prime")
  }else{
    console.log(i,"not a prime")
  }
}