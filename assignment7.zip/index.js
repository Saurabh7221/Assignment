//Problem 1: Print the Calendar date in the below format
//Problem 1: Print the Calendar date in the below format

let day=31;

for (let month=1;month<=12;month++){
  
  if (month==2){
    day=28;
    for (let day=1;day<=28;day++){
      console.log(day+"-"+month)
}
  }else if (month==4|| month==6|| month==9 || month==11){
    day=30;
    for (let day=1;day<=30;day++){
      console.log(day+"-"+month)
}
  }else{
    day=31;
    for (let day=1;day<=31;day++){
      console.log(day+"-"+month)
}
    
  }

}
