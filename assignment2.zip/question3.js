//Given 2 numbers a and b print which is greater or "both equal".
let a=5;
let b=4;
if (a<b){
  console.log("b is greater then a")
if (a==b){
  console.log("both equal")
}else if (a>b){
  console.log("a is greater then b")
}