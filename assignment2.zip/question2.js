 //If a person is allowed to drive in India print "Apply for a license" or "NA".
let x=19;

if (x>=18){
  console.log("Apply for a license");
}else{
  console.log("NA");
}