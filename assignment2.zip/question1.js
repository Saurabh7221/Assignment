let x=15
if (x%3==0){
  console.log("multiple of 3")
}