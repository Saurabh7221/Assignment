//Given stored username and password and input username and password, Print if the user can login or not.
let username="Saurabh";
let password=2468;
if (username=="Saurabh"){
  if (password==2468){
    console.log("login successfull");
  }else{
  console.log("incorrect password");
  }

}else{
console.log("invalid username");
}
