//Given a string count the number of words in that string
let str="Rahul kumar pandat";
let sum=0;
for(let i=0;i<=str.length-1;i++){
  if (str[i]==" "){
    sum+=1
  }
}console.log(sum+1);