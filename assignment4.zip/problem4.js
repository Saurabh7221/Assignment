//Problem 4: Print the average of even numbers from 1 to 100 (both included)
let x=1;
ave=0;
sum=0;
count=0;
while(x<=10){
  if (x%2==0){
    console.log(x);
    sum=sum+x;
    count=count+1;
    x++
  }else{
    x++
  }
}console.log("sum is ", sum);
console.log("count is", count);
console.log("Average is", sum/count)
