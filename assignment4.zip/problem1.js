//Problem 1: Print the numbers from the given starting point till ending point (including both start and end)
let x=1;
while (x<=10){
  console.log(x)
  x++;
}