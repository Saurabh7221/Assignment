let str="RonaldRHf"
let arr=[];
for (let i=0;i<=str.length-1;i++){
  if (str[i]=="R"){
    arr+="D"
  }else{
    arr+=str[i];
  }
   
}console.log(arr)