//Problem 3: Print the sum of all the multiples of 3 from 0 to the given limit
let x=0;
sum=0;
while (x<10){
  if (x%3==0){
    console.log(x)
    sum=sum+x;
    x++
  }else{
    x++;
}
}console.log("sum is",sum)