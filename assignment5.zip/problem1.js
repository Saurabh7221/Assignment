////Given an array print the position (starting with 1) and the element in a single line.
let arr=["SAURABH","RAHUL","SHIVAM","AJAY","GOLU"];
x=arr.length;
for (let i=1;i<=x;i++){
  console.log(i,arr[i-1]);
}
