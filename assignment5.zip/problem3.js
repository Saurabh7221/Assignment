//Given an array of numbers find the average of all the even numbers.
let arr1=[1,2,3,5,491,9411,94];
let sum=0;
let count=0;
let x=arr1.length;
for(let i=1;i<=x;i++){
  if (arr1[i]%2==0){
    sum=sum+arr1[i];
    count=count+1;
  }
}console.log("the average of all the even numbers in arr1",sum/count)