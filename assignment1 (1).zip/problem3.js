let x="Saurabh";
let y=19;
console.log(x,y);
console.log(typeof(x),typeof(y));
