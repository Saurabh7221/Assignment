let r="################   REPORT CARD  #################"
let school="    DAVID  MODEL  SENIOR   SECONDARY  SCHOOL    ";
let name="NAME  =  Saurabh Rana";
let grade="GRADE = 12th";
let sec="   ,    SEC = A";
let roll="ROLL NUMBER = 12";
let x="----------------------------------------------------"
console.log(r);
console.log(x);
console.log(x);
console.log(school);
console.log(x);
console.log(x);
console.log(name);
console.log(grade,sec);
console.log(roll);
console.log(x);
let y="                     MARKSHEET";
console.log(y);
console.log(x);
let k="SUBJECT            MARKS/100"
console.log(k);
console.log(x);
console.log(x);
let english="ENGLISH               90";
let maths="MATHS                 95";
let com="COMPUTER              97";
console.log(english);
console.log(maths);
console.log(com);