let x="Saurabh";
console.log(x);
x="Rakesh";
console.log(x);
x="Mamta";
console.log(x)