let day=31;
for(var month=1;month<=12;month++){
  if(month==2){
    day=28;
    for(let y=1;y<=day;y++){
      console.log(y,month)
    }
  }else if(month==3 || month==5 || month==9|| month==11){
    day=30;
    for(let z=1;z<=day;z++){
      console.log(z,month)
    }
  }else{
    day=31;
    for(let z=1;z<=day;z++){
      console.log(z,month)
  }
  }
}
