let x=5;
switch(x){
  case 1: console.log("Sunday");
    break;
  case 2: console.log("Monday");
    break;
  case 3: console.log("Tuesday");
    break;
  case 4: console.log("Wednesday");
    break;
  case 5: console.log("Thurday");
    break;
  case 6: console.log("Friday");
    break;
  case 7: console.log("Saturday");
}